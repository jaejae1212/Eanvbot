// models 폴더에 넣어주세요
const { Schema, model } = require("mongoose");

module.exports = model(
  "wordSave",
  new Schema({
    word: String,
    mean: String,
  })
);
