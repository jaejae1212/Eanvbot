// Buttons 폴더에 넣어주세요

const { EmbedBuilder } = require("discord.js");

const adminChannel = "1203283252761206901"; //관리자 채널 아이디를 입력해 주세요

module.exports = {
  name: "modalEx",
  /**
   *
   * @param {import("discord.js").ChatInputCommandInteraction} interaction
   */
  async execute(interaction) {
    const firstInput = interaction.fields.getTextInputValue("firstInput");
    const secondInput = interaction.fields.getTextInputValue("secondInput");
    //const threeInput = interaction.fields.getTextInputValue("threeInput");
    interaction.reply({
      ephemeral: true,
      content: `**[문의사항 제출 완료]\n\n닉네임 : ${firstInput}\n문의사항: ${secondInput}**`,
    });
    const embed = new EmbedBuilder()
      .setTitle(
        `[새로운 문의사항 도착]\n\n닉네임 : ${firstInput}\n문의사항 : ${secondInput}`
      )
      .setTimestamp()
      .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
      .setAuthor({
        name: interaction.user.tag,
        iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
      })
      //   .setDescription(
      //     `****`
      //   )
      .setColor("Green");
    interaction.client.channels.cache
      .get(adminChannel)
      ?.send({ embeds: [embed] });
  },
};
