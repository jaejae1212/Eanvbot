// Commands/* 폴더에 넣어주세요
const {
  SlashCommandBuilder,
  ModalBuilder,
  TextInputBuilder,
  ActionRowBuilder,
  TextInputStyle,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder().setName("문의").setDescription("문의사항 명령어"),
  /**
   *
   * @param {import("discord.js").ChatInputCommandInteraction} interaction
   */
  async execute(interaction) {
    //if (!message.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR));
    const buttons = new ActionRowBuilder({
      components: [
        new ButtonBuilder()
          .setCustomId("modalExButton")
          .setLabel("문의하기")
          .setEmoji("✅")
          .setStyle(ButtonStyle.Success),
      ],
    });
    const msg = await interaction.editReply({ components: [buttons] });
    const collector = msg.createMessageComponentCollector({
      time: 60000,
      //filter: (i) => i.user.id == interaction.user.id,
    });
    collector.on("collect", async (f) => {
      const modal = new ModalBuilder()

        .setCustomId("modalEx")
        .setTitle("문의 내용");

      const firstInput = new ActionRowBuilder({
        components: [
          new TextInputBuilder()
            .setCustomId("firstInput")
            .setPlaceholder("닉네임을 입력해 주세요")
            .setLabel("닉네임")
            .setMinLength(1)
            .setStyle(TextInputStyle.Short),
        ],
      });

      const secondInput = new ActionRowBuilder({
        components: [
          new TextInputBuilder()
            .setCustomId("secondInput")
            .setPlaceholder("문의내용을 입력해 주세요")
            .setLabel("문의내용")
            .setMinLength(1)
            /*.setMinLength(1)
            .setMinLength(2)*/
            .setStyle(TextInputStyle.Short),
        ],
      });

      /*
      const threeInput = new ActionRowBuilder({
        components: [
          new TextInputBuilder()
            .setCustomId("threeInput")
            .setPlaceholder("포지션을 입력해 주세요")
            .setLabel("포지션")
            .setStyle(TextInputStyle.Paragraph),
        ],
      });
      */
      modal.addComponents(firstInput, secondInput);
      await f.showModal(modal);

    });
  },
};
