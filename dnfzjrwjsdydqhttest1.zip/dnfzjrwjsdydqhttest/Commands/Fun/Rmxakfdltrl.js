// Commands/* 폴더에 넣어주세요
const {
  SlashCommandBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
} = require("discord.js");
const axios = require("axios").default;
const word_Schema = require("../../models/word");

let ApiKey = "09BA9E9B6EA070A56D2EAAA7CFE8C44F"; // https://stdict.korean.go.kr/openapi/openApiRegister.do 이 사이트에서 회원가입 후 API 키를 넣어주세요

module.exports = {
  data: new SlashCommandBuilder()
    .setName("끝말잇기")
    .setDescription("끝말잇기를 시작합니다."),
  /**
   *
   * @param {import("discord.js").ChatInputCommandInteraction} interaction
   */
  async execute(interaction) {
    let members = [];
    let member_order = 0;
    let deadUser = [];
    let words = [];
    let timeout_var;
    const getUser = async (id) => {
      return await interaction.client.users.fetch(id);
    };
    const gameStart = async () => {
      if (members.length < 2) {
        return interaction.editReply({
          content: `**인원이 부족해 끝말잇기를 시작하지 못했습니다.**`,
          embeds: [],
          components: [],
        });
      }
      const one_embed = new EmbedBuilder()
        .setTitle("끝말잇기 시작")
        .setDescription(`**<@${members[0]}>님 첫 단어를 말해주세요.**`)
        .setColor("Green")
        .setThumbnail(
          (await getUser(members[0])).displayAvatarURL({ dynamic: true })
        );
      interaction.editReply({ embeds: [one_embed], components: [] });
      const messageCollector = interaction.channel.createMessageCollector({
        filter: (i) => members.includes(i.author.id),
      });
      const wordTest = async (word) => {
        const word_find = await word_Schema.findOne({ word: word });
        if (word_find) {
          return word_find.mean;
        }
        const getFetch = (
          await axios.get(
            `https://stdict.korean.go.kr/api/search.do?certkey_no=4761&key=${ApiKey}&type_search=search&req_type=json&q=${word}&type1=word&`
          )
        ).data;
        if (!getFetch) {
          return null;
        }
        new word_Schema({
          word: word,
          mean: getFetch.channel.item[0].sense.definition,
        }).save();
        return getFetch.channel.item[0].sense.definition;
      };
      messageCollector.on("collect", async (d) => {
        if (members[member_order] != d.author.id) return;
        const sendMessage = async (content) => {
          d.reply(content)
            .then((f) => {
              setTimeout(() => {
                f.delete().catch(() => { });
              }, 10000);
            })
            .catch(() => {
              d.channel.send(content).then((f) => {
                setTimeout(() => {
                  f.delete().catch(() => { });
                }, 10000);
              });
            });
        };
        const gameEnd = async () => {
          // deadUser = 죽은 애들 차례대로 들어가있음, members = 승자 (한명임)
          deadUser.reverse();
          messageCollector.stop();
          let ranking = "";
          ranking += `\` 1 \` <@${members[0]}>\n`;
          for (let i = 1; i < deadUser.length + 1; i++) {
            ranking += `\` ${i + 1} \` <@${deadUser[i - 1]}>\n`;
          }
          const dssds_embed = new EmbedBuilder()
            .setTitle("끝말잇기 종료")
            .setDescription(`**${ranking}**`)
            .setColor("Green");
          interaction.editReply({ embeds: [dssds_embed] });
          return;
        };
        const nextMember = async (text, type) => {
          if (members.length == 1) {
            gameEnd();
            return;
          }
          if (type == true) {
            if (members[member_order]) {
            } else {
              if (members[member_order + 1]) {
                member_order++;
              } else {
                member_order = 0;
              }
            }
          } else {
            member_order++;
            if (!members[member_order]) {
              member_order = 0;
            }
          }
          const two_embed = new EmbedBuilder()
            .setTitle("끝말잇기 시작")
            .setDescription(
              `**<@${members[member_order]}>님이 \`${words[words.length - 1]
              }\` 단어를 이어주세요.\n\n${text}**`
            )
            .setColor("Green")
            .setThumbnail(
              (await getUser(members[member_order])).displayAvatarURL({
                dynamic: true,
              })
            );
          interaction.editReply({ embeds: [two_embed] });
          timeout_var = setTimeout(async () => {
            const End_embed = new EmbedBuilder()
              .setTitle("끝말잇기 탈락")
              .setDescription(
                `<@${members[member_order]}>님이 탈락하셨습니다.`
              )
              .setColor("Red")
              .setThumbnail(
                (await getUser(members[member_order])).displayAvatarURL({
                  dynamic: true,
                })
              );
            sendMessage({ embeds: [End_embed] });
            if (members.length == 1) {
              gameEnd();
            }
            deadUser.push(members[member_order]);
            members = members.filter((f) => f != members[member_order]);
            nextMember(text, true);
          }, 10000);
        };
        if (d.content.length < 2) {
          return sendMessage({ content: `**최소 글자 수는 2글자예요.**` });
        }
        if (/[~!@#$%^&*()_+|<>?:{}]/.test(d.content)) {
          return sendMessage({ content: `**특수문자는 입력하실 수 없어요.**` });
        }
        if (words.includes(d.content)) {
          return sendMessage({
            content: `**\`${d.content}\`는 이미 말한 단어입니다.**`,
          });
        }
        let lastWord = words[words.length - 1];
        let nowWord = d.content;
        if (lastWord) {
          if (
            lastWord.slice(lastWord.length - 1, lastWord.length) !=
            nowWord.slice(0, 1)
          ) {
            return sendMessage({
              content: `**\`${lastWord.slice(
                lastWord.length - 1,
                lastWord.length
              )}\`로 시작하는 단어를 말해주세요.**`,
            });
          }
        }
        setTimeout(() => {
          d.delete();
        }, 10000);
        const testWord = await wordTest(d.content);
        if (testWord == null) {
          return sendMessage({ content: `**없는 단어입니다.**` });
        } else {
          sendMessage({
            content: `**${testWord}**`,
          });
          words.push(d.content);
          if (timeout_var) {
            clearTimeout(timeout_var);
          }
          nextMember(testWord);
        }
      });
    };
    const members_gather = async () => {
      const members_gather_embed_update = () => {
        const MainEmbed = new EmbedBuilder()
          .setTitle("유저 참가 대기 중")
          .setDescription(
            `함께 끝말잇기할 분은 아래 참가하기 버튼을 눌러 주세요!\n 제한시간은 10초(10,000ms)입니다.\n> 참가자(${members.length
            }): ${members.length == 0 ? "" : `<@${members.join("> <@")}>`}`
          )
          .setColor("Blue");
        interaction.editReply({ embeds: [MainEmbed] });
      };
      members_gather_embed_update();
      const MainButton = new ButtonBuilder()
        .setCustomId("participation")
        .setLabel("참가하기")
        .setStyle(ButtonStyle.Primary);
      const MainRow = new ActionRowBuilder().addComponents(MainButton);
      const msg = await interaction.editReply({ components: [MainRow] });
      const collector = msg.createMessageComponentCollector({ time: 20000 });
      collector.on("collect", (f) => {
        if (members.includes(f.user.id)) {
          members = members.filter((d) => d != f.user.id);
          f.reply({ ephemeral: true, content: `**제외되었어요.**` });
          members_gather_embed_update();
          //   제외
        } else {
          members.push(f.user.id);
          f.reply({ ephemeral: true, content: `**추가되었어요.**` });
          members_gather_embed_update();
          // 추가
        }
      });
      collector.on("end", () => {
        gameStart();
      });
    };
    await members_gather();
  },
};
